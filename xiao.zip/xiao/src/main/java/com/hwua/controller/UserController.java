package com.hwua.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hwua.bean.User;
import com.hwua.service.UserService;
import com.hwua.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Objects;

@Controller
public class UserController {


    @Autowired
    private UserService userService;


    @RequestMapping(value = "/static/register", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
    public ModelAndView registerUser(User user) {
        userService.saveUser(user);

        ModelAndView mv = new ModelAndView("redirect:/static/login.jsp");

        return mv;
    }

    @RequestMapping("/logout")
    public ModelAndView logout(HttpSession session) {
        session.removeAttribute("user");
        ModelAndView mv = new ModelAndView("index");

        return mv;
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView login( String uname, String pwd, HttpSession session) {
        User user = userService.getUser(uname);
        ModelAndView mv = new ModelAndView();

        if(Objects.equals(user.getPwd(), MD5Util.string2MD5(pwd))) {
            session.setAttribute("user", user);
            mv.setViewName("index");
        } else {
            mv.setViewName("redirect:/static/login.jsp");
        }
        return mv;
    }

    @ResponseBody
    @RequestMapping("/static/checkCode")
    public String validateCode(String veryCode, HttpSession session) throws JsonProcessingException {
        String ok = new ObjectMapper().writeValueAsString("ok");
        String no = new ObjectMapper().writeValueAsString("no");
        String s = (String) session.getAttribute("validateCode");
        return Objects.equals(s, veryCode) ? ok : no;
    }

}
