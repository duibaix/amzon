package com.hwua.controller;

import com.hwua.bean.*;
import com.hwua.service.HomePageService;
import com.hwua.service.OrderService;
import com.hwua.service.ShopCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Controller
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private ShopCartService shopCartService;

    @Autowired
    private HomePageService homePageService;



    @RequestMapping(value = "checkout", method = RequestMethod.POST, produces = "application/json")
    public ModelAndView checkout(HttpSession session, @RequestBody List<ShopCart> list, String money) {
        User user = (User) session.getAttribute("user");
        String uid = user.getId();
        BigDecimal allMoney = new BigDecimal(money);
        Order order = new Order(null, user.getId(), user.getUname(), user.getAddress(), new Timestamp(System.currentTimeMillis()), allMoney);
        orderService.checkout(order);


        list.forEach(item -> {
            shopCartService.delByUidAndPid(uid, item.getPid());
            OrderDetail orderDetail = new OrderDetail(null, order.getId(), item.getPid(), item.getPnum(), item.getSinglePrice());
            Product product = homePageService.getProduct(orderDetail.getPid());
            homePageService.updateById(product.getId(), (product.getStock() - orderDetail.getQuantity()));
            orderService.checkoutDetail(orderDetail);
        });

        ModelAndView mv = new ModelAndView("shopping-result");

        return mv;
    }

    @RequestMapping("/processorder")
    public ModelAndView processorder(HttpSession session) {
        User user = (User) session.getAttribute("user");
        List<Order> orderList = orderService.getOrderById(user.getId());
        orderList.forEach(order -> {
            List<Product> productList = new ArrayList<>();
            List<OrderDetail> orderDetailList = orderService.getOderDetail(order.getId());
            orderDetailList.forEach(orderDetail -> {
                Product product = homePageService.getProduct(orderDetail.getPid());
                product.setCount(orderDetail.getQuantity());
                productList.add(product);
            });
            order.setProductlist(productList);
        });
/*        for(Order order : orderList) {
            List<Product> productList = new ArrayList<>();
            List<OrderDetail> orderDetailList = orderService.getOderDetail(order.getId());
            System.out.println("111111111111111111111111111111111111111");
            orderDetailList.forEach(System.out::println);
            for (OrderDetail orderDetail : orderDetailList) {
                Product product = homePageService.getProduct(orderDetail.getPid());
                productList.add(product);
                System.out.println(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
                System.out.println(product);
            }
            System.out.println("''''''''''''''''''''''''''''''''''''''''''''''''");
            order.setProductlist(productList);
            System.out.println(productList);
        }
        System.out.println("..........................................");
        orderList.forEach(System.out::println);*/
        session.setAttribute("orderList", orderList);

        ModelAndView mv = new ModelAndView("orders_view");

        return mv;
    }



}
