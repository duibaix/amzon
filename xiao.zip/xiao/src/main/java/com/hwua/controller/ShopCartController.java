package com.hwua.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hwua.bean.ShopCart;
import com.hwua.bean.User;
import com.hwua.service.ShopCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class ShopCartController {

    @Autowired
    private ShopCartService shopCartService;

    @RequestMapping("/addCart")
    public ModelAndView addCart(String pid, Integer count, HttpSession session, HttpServletResponse response, ShopCart shopCart) {
        User user = (User) session.getAttribute("user");
        shopCart.setAll(null, user.getId(), pid, count);
        response.addCookie(new Cookie("carId", shopCart.getId()));
        ModelAndView mv = new ModelAndView();

        if (shopCartService.addCart(shopCart)) {
            mv.setViewName("shopping");
        } else {
            mv.setViewName("index");
        }
        return mv;
    }

    @ResponseBody
    @RequestMapping(value = "/addcarGetBean", method = RequestMethod.POST, produces = "text/html;charset=utf-8")
    public String carGetBean(HttpSession session) throws JsonProcessingException {
        User user = (User) session.getAttribute("user");

        String jsonString = new ObjectMapper().writeValueAsString(shopCartService.getAllById(user.getId()));
        return jsonString;
    }


    @RequestMapping("/delshopcar")
    public ModelAndView delByUidAndPid(HttpSession session, String pid) {
        User user = (User) session.getAttribute("user");
        shopCartService.delByUidAndPid(user.getId(), pid);

        ModelAndView mv = new ModelAndView("shopping");

        return mv;
    }

    @RequestMapping("updatePnum")
    public ModelAndView updatePnumById(String pid, String pnum, HttpSession session) {
        User user = (User) session.getAttribute("user");
        ShopCart cartByUidAndPid = shopCartService.getCartByUidAndPid(user.getId(), pid);
        shopCartService.updatePnumById(Integer.parseInt(pnum), cartByUidAndPid.getId());

        ModelAndView mv = new ModelAndView("shopping");

        return mv;

    }



















    @RequestMapping("/testAdd")
    public void test() {
        shopCartService.getCartByUidAndPidTest("21", "9");
    }

    @RequestMapping("/testCookie")
    public String testCookie(HttpServletResponse response) throws JsonProcessingException {

        String jsonString = new ObjectMapper().writeValueAsString(shopCartService.getAllById("21"));

//        response.addCookie(new Cookie("user", "jsonString"));

        response.addCookie(new Cookie("user", jsonString));

        return "test";
    }
}
