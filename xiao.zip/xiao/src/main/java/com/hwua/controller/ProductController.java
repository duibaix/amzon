package com.hwua.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hwua.bean.Product;
import com.hwua.service.HomePageService;
import com.hwua.service.impl.NewsService;
import com.hwua.utils.MyPageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Objects;

@RestController
public class ProductController {

    @Autowired
    private HomePageService homePageService;

    @Autowired
    private NewsService newsService;

    @Autowired
    private MyPageHelper pageHelper;


    @RequestMapping("/index")
    public ModelAndView getAllProduct(HttpSession session) {
        PageHelper.startPage(pageHelper.getPageNum(), pageHelper.getPageSize());
        pageHelper.setProductList(homePageService.getAllProduct());
        PageInfo<Product> pageInfo = new PageInfo<>(pageHelper.getProductList());
        pageHelper.setPages(pageInfo.getPages());
        List<String> newsList = newsService.getAll();
        pageHelper.setMinor_id("");
        session.setAttribute("newsList", newsList);
        session.setAttribute("hotProduct", pageHelper.getProductList());
        session.setAttribute("pageHelper", pageHelper);
        ModelAndView mv = new ModelAndView("index");

        return mv;
    }


    @RequestMapping("/indexShowPor")
    public ModelAndView pageNumSearch(Integer currentPage, String minor_id, Model model) {
        pageHelper.setPageNum(currentPage);
        PageHelper.startPage(pageHelper.getPageNum(), pageHelper.getPageSize());

        if(Objects.equals(minor_id, null)) {
            pageHelper.setProductList(homePageService.getAllProduct());
        } else  {
            pageHelper.setProductList(homePageService.getProductMinorBySort(minor_id));
        }

        PageInfo<Product> pageInfo = new PageInfo<>(pageHelper.getProductList());
        pageHelper.setPages(pageInfo.getPages());
        model.addAttribute("pageHelper", pageHelper);
        ModelAndView mv = new ModelAndView("index");

        return mv;
    }


    @RequestMapping("/productDetail")
    public ModelAndView productDetail(String id, Model model) {

        Product product = homePageService.getProduct(id);
        model.addAttribute("productDetail", product);

        ModelAndView mv = new ModelAndView("product_view");

        return mv;
    }

    @RequestMapping("/productMinorSort")
    public ModelAndView getProductMinorBySort(String minor_id, Model model) {
        pageHelper.setPageNum(1);
        PageHelper.startPage(pageHelper.getPageNum(), pageHelper.getPageSize());
        pageHelper.setMinor_id(minor_id);
        pageHelper.setProductList(homePageService.getProductMinorBySort(minor_id));
        PageInfo<Product> pageInfo = new PageInfo<>(pageHelper.getProductList());
        pageHelper.setPages(pageInfo.getPages());
        model.addAttribute("pageHelper", pageHelper);

        ModelAndView mv = new ModelAndView("index");
        return mv;
    }



/*    @RequestMapping("/productMajorSort")
    public String getProductByMajorSort(String major_id, Model model) {
        pageHelper.setPageNum(1);
        PageHelper.startPage(pageHelper.getPageNum(), pageHelper.getPageSize());
        pageHelper.setMinor_id(major_id);
        pageHelper.setProductList(homePageService.getProductMajorBySort(major_id));
        PageInfo<Product> pageInfo = new PageInfo<>(pageHelper.getProductList());
        pageHelper.setPages(pageInfo.getPages());
        pageHelper.getProductList().forEach(System.out::println);
        model.addAttribute("pageHelper", pageHelper);

        return "index";
    }*/



    
}
