package com.hwua.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    private String id;
    private String uid;
    private String uname;
    private String uaddress;
    private Date create_time;
    private BigDecimal money;
    private int status = 1;
    private int type = 0;
    private int findorderid = 1;

    private OrderDetail orderDetail;
    private List<Product> productlist;

    public Order(String id, String uid, String uname, String address, Date date, BigDecimal money) {
        this.id = id;
        this.uid = uid;
        this.uname = uname;
        this.uaddress = address;
        this.create_time = date;
        this.money = money;
    }
}
