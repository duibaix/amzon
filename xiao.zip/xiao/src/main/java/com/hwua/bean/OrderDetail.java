package com.hwua.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDetail {

    private String id;
    private String oid;
    private String pid;
    private int quantity;
    private BigDecimal money;

}
