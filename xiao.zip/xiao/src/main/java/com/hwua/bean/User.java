package com.hwua.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    private String id;
    private String uname;
    private String pwd;
    private int sex;
    private Date birthday;
    private String idcard;
    private String email;
    private String mobile;
    private String address;
    private int utype;
    private int status;
    private String idcardfile;
    private String code;

}
