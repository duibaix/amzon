package com.hwua.bean;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    private String id;
    private String name;
    private String description;
    private Double price;
    private Integer stock;
    private String major_id;
    private String minor_id;
    private String abc;
    private Integer count;
    private BigDecimal money;

}
