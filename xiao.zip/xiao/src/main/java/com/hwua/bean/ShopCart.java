package com.hwua.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShopCart {

    private String id;
    private String uid;
    private String pid;
    private Integer pnum;

    private BigDecimal money;

    private BigDecimal singlePrice;

    private List<Product> productList;

    public void setAll(String id, String uid, String pid, Integer pnum) {
        this.id = id;
        this.uid = uid;
        this.pid = pid;
        this.pnum = pnum;
    }
}
