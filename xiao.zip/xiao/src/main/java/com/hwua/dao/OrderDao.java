package com.hwua.dao;

import com.hwua.bean.Order;
import com.hwua.bean.OrderDetail;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface OrderDao {

    @Insert("insert into amz_order values(null, #{uid}, #{uname}, #{uaddress}, #{create_time}, #{money}, #{status}, #{type}, #{findorderid})")
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "id")
    int checkout(Order order);


    @Select("select * from amz_order where uid = #{uid}")
    List<Order> getOrderById(@Param("uid") String uid);


    @Insert("insert into amz_order_detail values(null, #{oid}, #{pid}, #{quantity}, #{money})")
    int checkoutDetail(OrderDetail orderDetail);


    @Select("select * from amz_order_detail where oid = #{oid}")
    List<OrderDetail> getOderDetail(@Param("oid") String oid);

}
