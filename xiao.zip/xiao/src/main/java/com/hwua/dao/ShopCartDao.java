package com.hwua.dao;

import com.hwua.bean.ShopCart;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ShopCartDao {

    @Select("select * from amz_shop_cart where uid = #{uid}")
    List<ShopCart> getAllById(String id);

    @Select("select * from amz_shop_cart where uid = #{uid} and pid = #{pid}")
    ShopCart getCartByUidAndPid(@Param("uid") String uid, @Param("pid") String pid);

    @Insert("insert into amz_shop_cart values(#{id}, #{pid}, #{pnum}, #{uid})")
    int addCart(ShopCart shopCart);

    @Update("update amz_shop_cart set pnum = #{pnum} where id = #{id}")
    int updatePnumById(@Param("pnum") Integer pnum, @Param("id") String id);

    @Delete("delete from amz_shop_cart where uid = #{uid} and pid = #{pid}")
    int delByUidAndPid(@Param("uid") String uid, @Param("pid") String pid);


}
