package com.hwua.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface NewsDao {

    @Select("select content from amz_news")
    public List<String> getAll();
}
