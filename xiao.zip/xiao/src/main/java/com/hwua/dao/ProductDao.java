package com.hwua.dao;

import com.hwua.bean.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ProductDao {


    @Select("select * from amz_product")
    public List<Product> getAllProduct();

    @Select("select * from amz_product where id = #{id}")
    public Product getProduct(String id);

    @Update("update amz_product set stock = #{stock} where id = #{id}")
    int updateById(@Param("id") String id, @Param("stock") Integer stock);


    @Select("select * from amz_product where minor_id = #{minor_id}")
    public List<Product> getProductMinorBySort(String minor_id);

    @Select("select * from amz_product where major_id = #{major_id}")
    public List<Product> getProductMajorBySort(String major_id);


}
