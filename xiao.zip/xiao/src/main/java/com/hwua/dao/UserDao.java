package com.hwua.dao;

import com.hwua.bean.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserDao {

    @Insert("insert into amz_user values(null, #{uname}, #{pwd}, #{sex}, #{birthday}, #{idcard}, #{email}, #{mobile}, #{address}, #{utype}, 1, 'null', #{code})")
    public void saveUser(User user);

    @Select("select * from amz_user where uname = #{uname}")
    public User getUser(String uname);

}
