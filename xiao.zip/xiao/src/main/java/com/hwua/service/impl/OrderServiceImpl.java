package com.hwua.service.impl;

import com.hwua.bean.Order;
import com.hwua.bean.OrderDetail;
import com.hwua.dao.OrderDao;
import com.hwua.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    public Boolean checkout(Order order) {
        return orderDao.checkout(order) > 0? true : false;
    }

    public List<Order> getOrderById(String id) {
        return orderDao.getOrderById(id);
    }

    public Boolean checkoutDetail(OrderDetail orderDetail) {
        return orderDao.checkoutDetail(orderDetail) > 0? true : false;
    }

    public List<OrderDetail> getOderDetail(String oid) {
        return orderDao.getOderDetail(oid);
    }
}
