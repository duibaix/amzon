package com.hwua.service;

import com.hwua.bean.Product;
import com.hwua.bean.ShopCart;

import java.util.List;

public interface ShopCartService {

    List<Product> getAllById(String uid);

    Boolean addCart(ShopCart shopCart);

    Boolean updatePnumById(Integer pnum, String carId);

    ShopCart getCartByUidAndPid(String uid, String pid);

    void getCartByUidAndPidTest(String uid, String pid);

    Boolean delByUidAndPid(String uid, String pid);


}
