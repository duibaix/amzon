package com.hwua.service;

import com.hwua.bean.Product;

import java.util.List;

public interface HomePageService {

    List<Product> getAllProduct();

    Product getProduct(String id);

    List<Product> getProductMinorBySort(String minor_id);

    Boolean updateById(String id, Integer stock);

    List<Product> getProductMajorBySort(String major_id);

}
