package com.hwua.service.impl;

import com.hwua.dao.NewsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsService {

    @Autowired
    private NewsDao newsDao;

    public List<String> getAll() {
        return newsDao.getAll();
    }
}
