package com.hwua.service.impl;

import com.hwua.bean.Product;
import com.hwua.dao.ProductDao;
import com.hwua.service.HomePageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HomePageServiceImpl implements HomePageService {


    @Autowired
    private ProductDao productDao;


    @Override
    public List<Product> getAllProduct() {
        return productDao.getAllProduct();
    }

    @Override
    public Product getProduct(String id) {
        return productDao.getProduct(id);
    }

    @Override
    public List<Product> getProductMinorBySort(String minor_id) {
        return productDao.getProductMinorBySort(minor_id);
    }

    @Override
    public Boolean updateById(String id, Integer stock) {
        return productDao.updateById(id, stock) > 0 ? true : false;
    }

    public List<Product> getProductMajorBySort(String major_id) {
        return productDao.getProductMajorBySort(major_id);
    }

}
