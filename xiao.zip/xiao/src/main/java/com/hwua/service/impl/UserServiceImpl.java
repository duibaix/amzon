package com.hwua.service.impl;

import com.hwua.bean.User;
import com.hwua.dao.UserDao;
import com.hwua.service.UserService;
import com.hwua.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;


    @Override
    public boolean saveUser(User user) {
        user.setPwd(MD5Util.string2MD5(user.getPwd()));
        userDao.saveUser(user);
        return true;
    }

    @Override
    public User getUser(String uname) {

        User user = userDao.getUser(uname);


        return user;
    }

}
