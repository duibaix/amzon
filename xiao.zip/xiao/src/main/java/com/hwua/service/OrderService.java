package com.hwua.service;

import com.hwua.bean.Order;
import com.hwua.bean.OrderDetail;

import java.util.List;

public interface OrderService {

    Boolean checkout(Order order);

    List<Order> getOrderById(String id);

    Boolean checkoutDetail(OrderDetail orderDetail);

    List<OrderDetail> getOderDetail(String oid);


}
