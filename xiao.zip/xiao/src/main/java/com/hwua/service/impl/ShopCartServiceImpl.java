package com.hwua.service.impl;

import com.hwua.bean.Product;
import com.hwua.bean.ShopCart;
import com.hwua.dao.ProductDao;
import com.hwua.dao.ShopCartDao;
import com.hwua.service.ShopCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class ShopCartServiceImpl implements ShopCartService{

    @Autowired
    private ShopCartDao shopCartDao;

    @Autowired
    private ProductDao productDao;


    @Override
    public List<Product> getAllById(String uid) {
        List<ShopCart> shopCartList = shopCartDao.getAllById(uid);
        List<Product> productList = new ArrayList<>();
        shopCartList.forEach(shopCart -> {
            Product product = productDao.getProduct(shopCart.getPid());
            product.setCount(shopCart.getPnum());
            productList.add(product);
        });
        return productList;
    }

    @Override
    public Boolean addCart(ShopCart shopCart) {
        if (Objects.equals(shopCartDao.getCartByUidAndPid(shopCart.getUid(), shopCart.getPid()), null)) {
            return shopCartDao.addCart(shopCart) > 0 ? true : false;
        } else {
            return shopCartDao.updatePnumById(shopCart.getPnum() + 1, shopCart.getId()) > 0 ? true : false;
        }
    }

    @Override
    public Boolean updatePnumById(Integer pnum, String carId) {
        return shopCartDao.updatePnumById(pnum, carId) > 0 ? true : false;
    }

    @Override
    public ShopCart getCartByUidAndPid(String uid, String pid) {

        return shopCartDao.getCartByUidAndPid(uid, pid);
    }

    public Boolean delByUidAndPid(String uid, String pid) {
        return shopCartDao.delByUidAndPid(uid, pid) > 0 ? true : false;
    }













    public void getCartByUidAndPidTest(String uid, String pid) {
        if (Objects.equals(shopCartDao.getCartByUidAndPid(uid, pid), null)) {
            System.out.println("uShopCart == null");
        } else {
            System.out.println("............");
        }
    }




}
