package com.hwua.service;

import com.hwua.bean.User;

public interface UserService {

    public boolean saveUser(User user);

    public User getUser(String id);
}
