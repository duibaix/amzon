package com.hwua.utils;

import com.hwua.bean.Product;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class MyPageHelper {

    /**
     * 当前页
     */
    private int pageNum = 1;

    /**
     * 一页最多显示个数
     */
    private int pageSize = 12;

    /**
     * 总页码
     */
    private int pages;

    /**
     * 大分类
     */
    private String major_id;

    /**
     * 分类
     */
    private String minor_id;

    private List<Product> productList;

}
