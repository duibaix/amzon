package com.hwua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XiaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
